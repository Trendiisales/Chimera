#pragma once

namespace shadow {
    class MultiSymbolExecutor;
}

extern shadow::MultiSymbolExecutor* g_executor;
