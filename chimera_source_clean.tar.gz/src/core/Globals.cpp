#include "core/Globals.hpp"

shadow::MultiSymbolExecutor* g_executor = nullptr;
