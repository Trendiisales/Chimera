#include "GuiState.hpp"

GuiState g_gui;
std::atomic<uint64_t> g_gui_seq{0};
