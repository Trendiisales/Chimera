#include "gui/GUIBroadcaster.hpp"
#include "gui/WsServer.hpp"
#include "gui/ExecutionSnapshot.hpp"
#include "gui/TradeHistory.hpp"
#include "shadow/MultiSymbolExecutor.hpp"
#include <thread>
#include <chrono>

extern WsServer* g_wsServer;
extern shadow::MultiSymbolExecutor* g_executor;

static uint64_t g_start_time_ms = 0;

namespace Chimera {

GUIBroadcaster::GUIBroadcaster() : ws_(nullptr) {
    if (g_start_time_ms == 0) {
        g_start_time_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()
        ).count();
    }
}

GUIBroadcaster::~GUIBroadcaster() {
    stop();
}

void GUIBroadcaster::start() {
    ws_ = g_wsServer;

    std::thread([this]() {
        while (true) {
            if (!g_executor) {
                std::this_thread::sleep_for(std::chrono::milliseconds(1000));
                continue;
            }

            gui::ExecutionSnapshot snap;
            
            // Calculate uptime
            uint64_t now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now().time_since_epoch()
            ).count();
            uint64_t uptime_ms = now_ms - g_start_time_ms;
            snap.ts = uptime_ms / 1000;
            
            // Get latency regime from ExecutionRouter
            auto regime_snap = g_executor->router().latency().snapshot();
            const char* regime_str = 
                regime_snap.regime == LatencyRegime::FAST ? "FAST" :
                regime_snap.regime == LatencyRegime::NORMAL ? "NORMAL" :
                regime_snap.regime == LatencyRegime::DEGRADED ? "DEGRADED" : "HALT";
            
            double fix_rtt_ms = regime_snap.p50_ms;

            // XAU data
            auto* xau_exec = g_executor->getExecutor("XAUUSD");
            if (xau_exec) {
                auto& xau = snap.symbols["XAUUSD"];
                xau.bid = xau_exec->getLastBid();
                xau.ask = xau_exec->getLastAsk();
                xau.spread = xau_exec->getSpread();
                xau.latency_ms = fix_rtt_ms;
                xau.trades = xau_exec->getTradesThisHour();
                xau.rejects = xau_exec->getTotalRejections();
                xau.legs = xau_exec->getActiveLegs();
                xau.session = "NY";
                xau.regime = regime_str;

                int legs = xau_exec->getActiveLegs();
                xau.state = (legs > 0) ? "IN_POSITION" : "OPEN";

                xau.gates["session"] = gui::Gate(true, "active", "");
                xau.gates["spread"] = gui::Gate(xau.spread < 0.50, "OK", xau.spread >= 0.50 ? "spread too wide" : "");
                xau.gates["latency"] = gui::Gate(fix_rtt_ms < 8.0, regime_str, fix_rtt_ms >= 8.0 ? "latency high" : "");
                xau.gates["edge"] = gui::Gate(true, "checking", "");
                xau.gates["cooldown"] = gui::Gate(true, "ready", "");

                xau.cost.total_bps = 28.0;
                xau.edge.raw_bps = 31.5;
                xau.edge.latency_adj_bps = 26.2;
                xau.edge.required_bps = 28.0;

                xau.impulse.raw = 1.42;
                xau.impulse.latency_adj = 0.88;
                xau.impulse.min_required = 1.10;

                xau.pnl.shadow = xau_exec->getRealizedPnL();
                xau.pnl.cash = 0.0;
            }

            // XAG data
            auto* xag_exec = g_executor->getExecutor("XAGUSD");
            if (xag_exec) {
                auto& xag = snap.symbols["XAGUSD"];
                xag.bid = xag_exec->getLastBid();
                xag.ask = xag_exec->getLastAsk();
                xag.spread = xag_exec->getSpread();
                xag.latency_ms = fix_rtt_ms;
                xag.trades = xag_exec->getTradesThisHour();
                xag.rejects = xag_exec->getTotalRejections();
                xag.legs = xag_exec->getActiveLegs();
                xag.session = "NY";
                xag.regime = regime_str;

                int legs = xag_exec->getActiveLegs();
                xag.state = (legs > 0) ? "IN_POSITION" : "OPEN";

                xag.gates["session"] = gui::Gate(true, "active", "");
                xag.gates["spread"] = gui::Gate(xag.spread < 0.05, "OK", xag.spread >= 0.05 ? "spread too wide" : "");
                xag.gates["latency"] = gui::Gate(fix_rtt_ms < 8.0, regime_str, fix_rtt_ms >= 8.0 ? "latency high" : "");
                xag.gates["edge"] = gui::Gate(true, "checking", "");
                xag.gates["cooldown"] = gui::Gate(true, "ready", "");

                xag.cost.total_bps = 15.0;
                xag.edge.raw_bps = 12.0;
                xag.edge.latency_adj_bps = 10.0;
                xag.edge.required_bps = 15.0;

                xag.impulse.raw = 0.65;
                xag.impulse.latency_adj = 0.52;
                xag.impulse.min_required = 0.80;

                xag.pnl.shadow = xag_exec->getRealizedPnL();
                xag.pnl.cash = 0.0;
            }

            // Populate blotter from TradeHistory
            snap.blotter = gui::TradeHistory::instance().getTrades();

            snap.governor.daily_dd = "OK";
            snap.governor.hourly_loss = "OK";
            snap.governor.reject_rate = "LOW";
            snap.governor.action = "NONE";

            snap.connections.fix = true;
            snap.connections.ctrader = true;

            std::string json = gui::EmitJSON(snap);

            if (ws_) {
                ws_->broadcast(json);
            }

            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
    }).detach();
}

void GUIBroadcaster::stop() {
}

} // namespace Chimera
