#include "gui/WsServer.hpp"

WsServer* g_wsServer = nullptr;
