#include "LatencyStats.hpp"
LatencyStats g_latency;
