#pragma once
// Stub for ExecutionAuthority - not needed in V1 SHADOW mode

namespace Chimera {

// Minimal stub - all checks pass in SHADOW mode
inline bool checkExecutionAuthority() {
    return true;
}

} // namespace Chimera
