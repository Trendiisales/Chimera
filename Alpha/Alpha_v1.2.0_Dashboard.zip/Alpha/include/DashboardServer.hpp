// ═══════════════════════════════════════════════════════════════════════════════
// Alpha Trading System - WebSocket Dashboard Server
// ═══════════════════════════════════════════════════════════════════════════════
// VERSION: 1.0.0
// PURPOSE: Serve real-time data to the dashboard HTML
// PROTOCOL: Simple JSON over WebSocket (port 8080)
// ═══════════════════════════════════════════════════════════════════════════════
#pragma once

#include "core/Types.hpp"
#include <string>
#include <thread>
#include <atomic>
#include <mutex>
#include <queue>
#include <vector>
#include <sstream>
#include <iomanip>
#include <cstring>
#include <functional>

// Platform includes
#ifdef _WIN32
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #pragma comment(lib, "ws2_32.lib")
    typedef int socklen_t;
    #define CLOSE_SOCKET(s) closesocket(s)
#else
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <unistd.h>
    #include <fcntl.h>
    #include <arpa/inet.h>
    #define SOCKET int
    #define CLOSE_SOCKET(s) close(s)
    #define INVALID_SOCKET -1
#endif

#include <openssl/sha.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/buffer.h>

namespace Alpha {

// ═══════════════════════════════════════════════════════════════════════════════
// SIMPLE BASE64 ENCODER
// ═══════════════════════════════════════════════════════════════════════════════
inline std::string base64_encode(const unsigned char* data, size_t len) {
    static const char* chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string result;
    result.reserve(((len + 2) / 3) * 4);
    
    for (size_t i = 0; i < len; i += 3) {
        unsigned int n = (data[i] << 16);
        if (i + 1 < len) n |= (data[i + 1] << 8);
        if (i + 2 < len) n |= data[i + 2];
        
        result += chars[(n >> 18) & 0x3F];
        result += chars[(n >> 12) & 0x3F];
        result += (i + 1 < len) ? chars[(n >> 6) & 0x3F] : '=';
        result += (i + 2 < len) ? chars[n & 0x3F] : '=';
    }
    return result;
}

// ═══════════════════════════════════════════════════════════════════════════════
// DASHBOARD DATA STRUCTURES
// ═══════════════════════════════════════════════════════════════════════════════

struct EngineStatus {
    Instrument instrument = Instrument::INVALID;
    EngineState state = EngineState::INIT;
    
    // Prices
    double bid = 0, ask = 0, spread = 0;
    
    // Stats
    uint64_t ticks = 0;
    int trades = 0;
    double pnl_bps = 0;
    
    // Session
    std::string session = "OFF";
    std::string session_type = "off";
    double multiplier = 0;
    
    // Expectancy
    double expectancy = 0;
    double win_rate = 0;
    
    // Regime
    std::string regime = "QUIET";
    double momentum = 0;
    double volatility = 0;
    double spread_bps = 0;
    
    // Position
    bool has_position = false;
    std::string pos_side = "FLAT";
    double pos_entry = 0;
    double pos_size = 0;
    double pos_pnl_bps = 0;
    uint64_t pos_hold_ms = 0;
    bool pos_trailing = false;
    
    std::string to_json() const {
        std::ostringstream ss;
        ss << std::fixed << std::setprecision(2);
        ss << "{";
        ss << "\"state\":\"" << engine_state_str(state) << "\",";
        ss << "\"bid\":" << bid << ",";
        ss << "\"ask\":" << ask << ",";
        ss << "\"spread\":" << spread << ",";
        ss << "\"ticks\":" << ticks << ",";
        ss << "\"trades\":" << trades << ",";
        ss << "\"pnl\":" << std::setprecision(1) << pnl_bps << ",";
        ss << "\"session\":\"" << session << "\",";
        ss << "\"session_type\":\"" << session_type << "\",";
        ss << "\"multiplier\":" << std::setprecision(1) << multiplier << ",";
        ss << "\"expectancy\":" << expectancy << ",";
        ss << "\"win_rate\":" << std::setprecision(2) << win_rate << ",";
        ss << "\"regime\":\"" << regime << "\",";
        ss << "\"momentum\":" << momentum << ",";
        ss << "\"volatility\":" << volatility << ",";
        ss << "\"spread_bps\":" << spread_bps << ",";
        ss << "\"position\":{";
        ss << "\"side\":\"" << pos_side << "\",";
        ss << "\"entry\":" << std::setprecision(2) << pos_entry << ",";
        ss << "\"size\":" << pos_size << ",";
        ss << "\"pnl_bps\":" << std::setprecision(1) << pos_pnl_bps << ",";
        ss << "\"hold_time\":" << pos_hold_ms << ",";
        ss << "\"trailing\":" << (pos_trailing ? "true" : "false");
        ss << "}";
        ss << "}";
        return ss.str();
    }
};

struct DashboardStatus {
    uint64_t uptime_s = 0;
    uint64_t total_ticks = 0;
    int total_trades = 0;
    double total_pnl = 0;
    int daily_trades = 0;
    double daily_pnl = 0;
    
    EngineStatus xauusd;
    EngineStatus nas100;
    
    std::string to_json() const {
        std::ostringstream ss;
        ss << std::fixed;
        ss << "{\"type\":\"status\",";
        ss << "\"uptime\":" << uptime_s << ",";
        ss << "\"total_ticks\":" << total_ticks << ",";
        ss << "\"total_trades\":" << total_trades << ",";
        ss << "\"total_pnl\":" << std::setprecision(1) << total_pnl << ",";
        ss << "\"daily_trades\":" << daily_trades << ",";
        ss << "\"daily_pnl\":" << std::setprecision(2) << daily_pnl << ",";
        ss << "\"xauusd\":" << xauusd.to_json() << ",";
        ss << "\"nas100\":" << nas100.to_json();
        ss << "}";
        return ss.str();
    }
};

struct TradeRecord {
    uint64_t timestamp = 0;
    std::string instrument;
    std::string side;
    double size = 0;
    double entry = 0;
    double exit_price = 0;
    double pnl_bps = 0;
    std::string reason;
    
    std::string to_json() const {
        std::ostringstream ss;
        ss << std::fixed << std::setprecision(2);
        ss << "{\"type\":\"trade\",";
        ss << "\"time\":" << timestamp << ",";
        ss << "\"instrument\":\"" << instrument << "\",";
        ss << "\"side\":\"" << side << "\",";
        ss << "\"size\":" << size << ",";
        ss << "\"entry\":" << entry << ",";
        ss << "\"exit\":" << exit_price << ",";
        ss << "\"pnl\":" << std::setprecision(1) << pnl_bps << ",";
        ss << "\"reason\":\"" << reason << "\"";
        ss << "}";
        return ss.str();
    }
};

// ═══════════════════════════════════════════════════════════════════════════════
// WEBSOCKET DASHBOARD SERVER
// ═══════════════════════════════════════════════════════════════════════════════

class DashboardServer {
public:
    DashboardServer(uint16_t port = 8080) noexcept 
        : port_(port), running_(false), server_socket_(INVALID_SOCKET) {}
    
    ~DashboardServer() {
        stop();
    }
    
    bool start() noexcept {
        if (running_.load()) return false;
        
#ifdef _WIN32
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
            std::cerr << "[Dashboard] WSAStartup failed\n";
            return false;
        }
#endif
        
        server_socket_ = socket(AF_INET, SOCK_STREAM, 0);
        if (server_socket_ == INVALID_SOCKET) {
            std::cerr << "[Dashboard] Failed to create socket\n";
            return false;
        }
        
        int opt = 1;
        setsockopt(server_socket_, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));
        
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(port_);
        
        if (bind(server_socket_, (sockaddr*)&addr, sizeof(addr)) < 0) {
            std::cerr << "[Dashboard] Failed to bind port " << port_ << "\n";
            CLOSE_SOCKET(server_socket_);
            return false;
        }
        
        if (listen(server_socket_, 5) < 0) {
            std::cerr << "[Dashboard] Failed to listen\n";
            CLOSE_SOCKET(server_socket_);
            return false;
        }
        
        running_.store(true);
        accept_thread_ = std::thread(&DashboardServer::accept_loop, this);
        
        std::cout << "[Dashboard] Server started on port " << port_ << "\n";
        return true;
    }
    
    void stop() noexcept {
        if (!running_.load()) return;
        
        running_.store(false);
        
        // Close all client sockets
        {
            std::lock_guard<std::mutex> lock(clients_mutex_);
            for (SOCKET client : clients_) {
                CLOSE_SOCKET(client);
            }
            clients_.clear();
        }
        
        // Close server socket
        if (server_socket_ != INVALID_SOCKET) {
            CLOSE_SOCKET(server_socket_);
            server_socket_ = INVALID_SOCKET;
        }
        
        if (accept_thread_.joinable()) {
            accept_thread_.join();
        }
        
#ifdef _WIN32
        WSACleanup();
#endif
        
        std::cout << "[Dashboard] Server stopped\n";
    }
    
    void broadcast(const std::string& json) noexcept {
        if (!running_.load()) return;
        
        std::vector<uint8_t> frame = make_ws_frame(json);
        
        std::lock_guard<std::mutex> lock(clients_mutex_);
        std::vector<SOCKET> dead_clients;
        
        for (SOCKET client : clients_) {
            if (send(client, (const char*)frame.data(), (int)frame.size(), 0) <= 0) {
                dead_clients.push_back(client);
            }
        }
        
        // Remove dead clients
        for (SOCKET dead : dead_clients) {
            CLOSE_SOCKET(dead);
            clients_.erase(std::remove(clients_.begin(), clients_.end(), dead), clients_.end());
        }
    }
    
    void broadcast_status(const DashboardStatus& status) noexcept {
        broadcast(status.to_json());
    }
    
    void broadcast_trade(const TradeRecord& trade) noexcept {
        broadcast(trade.to_json());
    }
    
    [[nodiscard]] bool is_running() const noexcept { return running_.load(); }
    [[nodiscard]] size_t client_count() const noexcept {
        std::lock_guard<std::mutex> lock(clients_mutex_);
        return clients_.size();
    }

private:
    void accept_loop() noexcept {
        while (running_.load()) {
            fd_set readfds;
            FD_ZERO(&readfds);
            FD_SET(server_socket_, &readfds);
            
            timeval tv;
            tv.tv_sec = 1;
            tv.tv_usec = 0;
            
            int result = select((int)server_socket_ + 1, &readfds, nullptr, nullptr, &tv);
            if (result <= 0) continue;
            
            sockaddr_in client_addr;
            socklen_t client_len = sizeof(client_addr);
            SOCKET client = accept(server_socket_, (sockaddr*)&client_addr, &client_len);
            
            if (client == INVALID_SOCKET) continue;
            
            // Handle WebSocket handshake in separate thread
            std::thread([this, client]() {
                if (handle_handshake(client)) {
                    std::lock_guard<std::mutex> lock(clients_mutex_);
                    clients_.push_back(client);
                    std::cout << "[Dashboard] Client connected (total: " << clients_.size() << ")\n";
                } else {
                    CLOSE_SOCKET(client);
                }
            }).detach();
        }
    }
    
    bool handle_handshake(SOCKET client) noexcept {
        char buffer[4096];
        int received = recv(client, buffer, sizeof(buffer) - 1, 0);
        if (received <= 0) return false;
        buffer[received] = '\0';
        
        std::string request(buffer);
        
        // Check if this is a WebSocket upgrade request
        size_t key_pos = request.find("Sec-WebSocket-Key: ");
        
        if (key_pos == std::string::npos) {
            // Regular HTTP request - serve the dashboard HTML
            if (request.find("GET ") == 0) {
                serve_http(client, request);
            }
            return false;  // Don't add to WebSocket clients
        }
        
        // WebSocket upgrade
        key_pos += 19;
        size_t key_end = request.find("\r\n", key_pos);
        if (key_end == std::string::npos) return false;
        
        std::string key = request.substr(key_pos, key_end - key_pos);
        
        // Generate accept key
        std::string accept_key = generate_accept_key(key);
        
        // Send handshake response
        std::ostringstream response;
        response << "HTTP/1.1 101 Switching Protocols\r\n";
        response << "Upgrade: websocket\r\n";
        response << "Connection: Upgrade\r\n";
        response << "Sec-WebSocket-Accept: " << accept_key << "\r\n";
        response << "\r\n";
        
        std::string resp = response.str();
        return send(client, resp.c_str(), (int)resp.length(), 0) > 0;
    }
    
    void serve_http(SOCKET client, const std::string& request) noexcept {
        // Extract path
        size_t path_start = request.find("GET ") + 4;
        size_t path_end = request.find(" HTTP");
        std::string path = request.substr(path_start, path_end - path_start);
        
        // Serve dashboard HTML
        if (path == "/" || path == "/alpha_dashboard.html" || path.find("dashboard") != std::string::npos) {
            std::string html = get_dashboard_html();
            
            std::ostringstream response;
            response << "HTTP/1.1 200 OK\r\n";
            response << "Content-Type: text/html\r\n";
            response << "Content-Length: " << html.length() << "\r\n";
            response << "Connection: close\r\n";
            response << "\r\n";
            response << html;
            
            std::string resp = response.str();
            send(client, resp.c_str(), (int)resp.length(), 0);
        } else {
            // 404
            std::string body = "<html><body><h1>404 Not Found</h1></body></html>";
            std::ostringstream response;
            response << "HTTP/1.1 404 Not Found\r\n";
            response << "Content-Type: text/html\r\n";
            response << "Content-Length: " << body.length() << "\r\n";
            response << "Connection: close\r\n";
            response << "\r\n";
            response << body;
            
            std::string resp = response.str();
            send(client, resp.c_str(), (int)resp.length(), 0);
        }
        
        CLOSE_SOCKET(client);
    }
    
    std::string get_dashboard_html() noexcept {
        return R"HTML(<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alpha Trading System v1.2.0</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #0a0a0f;
            color: #e0e0e0;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            padding: 20px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        .header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            border: 1px solid #0f3460;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { color: #ffd700; font-size: 24px; }
        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .status-live { background: #00dd00; color: #000; }
        .status-shadow { background: #ff8c00; color: #000; }
        .status-disconnected { background: #dd0000; color: #fff; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; }
        .panel {
            background: #12121a;
            border: 1px solid #2a2a3a;
            border-radius: 8px;
            overflow: hidden;
        }
        .panel-header {
            background: #1a1a2e;
            padding: 12px 16px;
            border-bottom: 1px solid #2a2a3a;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
        }
        .panel-body { padding: 16px; }
        .instrument-gold { color: #ffd700; }
        .instrument-nas { color: #00aaff; }
        .metric { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #1a1a2a; }
        .metric:last-child { border-bottom: none; }
        .metric-label { color: #808090; }
        .metric-value { font-weight: bold; }
        .positive { color: #00dd00; }
        .negative { color: #dd0000; }
        .neutral { color: #808090; }
        .trade-row { padding: 10px; border-bottom: 1px solid #1a1a2a; display: flex; justify-content: space-between; }
        .trade-row:last-child { border-bottom: none; }
        .ws-status { font-size: 12px; color: #808090; }
        .ws-connected { color: #00dd00; }
        .ws-disconnected { color: #dd0000; }
        .session-asia { color: #ff6b6b; }
        .session-london { color: #4ecdc4; }
        .session-ny { color: #ffe66d; }
        #lastUpdate { font-size: 12px; color: #606070; margin-top: 20px; text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>🏛️ ALPHA TRADING SYSTEM</h1>
                <div style="color: #808090; margin-top: 5px;">XAUUSD • NAS100 | v1.2.0</div>
            </div>
            <div style="text-align: right;">
                <div id="modeStatus" class="status-badge status-disconnected">DISCONNECTED</div>
                <div class="ws-status" style="margin-top: 8px;">
                    WebSocket: <span id="wsStatus" class="ws-disconnected">●</span>
                </div>
            </div>
        </div>
        
        <div class="grid">
            <div class="panel">
                <div class="panel-header">
                    <span>⚡ SYSTEM</span>
                    <span id="uptime">00:00:00</span>
                </div>
                <div class="panel-body">
                    <div class="metric">
                        <span class="metric-label">FIX Quote</span>
                        <span id="fixQuote" class="metric-value neutral">--</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">FIX Trade</span>
                        <span id="fixTrade" class="metric-value neutral">--</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Session</span>
                        <span id="session" class="metric-value">--</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Total Trades</span>
                        <span id="totalTrades" class="metric-value">0</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Total P&L</span>
                        <span id="totalPnl" class="metric-value neutral">$0.00</span>
                    </div>
                </div>
            </div>
            
            <div class="panel">
                <div class="panel-header">
                    <span class="instrument-gold">🥇 XAUUSD</span>
                    <span id="goldRegime">--</span>
                </div>
                <div class="panel-body">
                    <div class="metric">
                        <span class="metric-label">Bid / Ask</span>
                        <span id="goldPrice" class="metric-value">-- / --</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Spread</span>
                        <span id="goldSpread" class="metric-value">-- bps</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">ATR Ratio</span>
                        <span id="goldAtr" class="metric-value">--</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Position</span>
                        <span id="goldPosition" class="metric-value neutral">FLAT</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">P&L</span>
                        <span id="goldPnl" class="metric-value neutral">$0.00</span>
                    </div>
                </div>
            </div>
            
            <div class="panel">
                <div class="panel-header">
                    <span class="instrument-nas">📈 NAS100</span>
                    <span id="nasRegime">--</span>
                </div>
                <div class="panel-body">
                    <div class="metric">
                        <span class="metric-label">Bid / Ask</span>
                        <span id="nasPrice" class="metric-value">-- / --</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Spread</span>
                        <span id="nasSpread" class="metric-value">-- bps</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">ATR Ratio</span>
                        <span id="nasAtr" class="metric-value">--</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">Position</span>
                        <span id="nasPosition" class="metric-value neutral">FLAT</span>
                    </div>
                    <div class="metric">
                        <span class="metric-label">P&L</span>
                        <span id="nasPnl" class="metric-value neutral">$0.00</span>
                    </div>
                </div>
            </div>
            
            <div class="panel">
                <div class="panel-header">
                    <span>📊 RECENT TRADES</span>
                </div>
                <div class="panel-body" id="trades">
                    <div style="color: #606070; text-align: center; padding: 20px;">No trades yet</div>
                </div>
            </div>
        </div>
        
        <div id="lastUpdate">Last update: --</div>
    </div>
    
    <script>
        let ws = null;
        let reconnectInterval = null;
        
        function connect() {
            const wsUrl = `ws://${window.location.host}`;
            ws = new WebSocket(wsUrl);
            
            ws.onopen = () => {
                console.log('WebSocket connected');
                document.getElementById('wsStatus').className = 'ws-connected';
                document.getElementById('wsStatus').textContent = '● Connected';
                if (reconnectInterval) {
                    clearInterval(reconnectInterval);
                    reconnectInterval = null;
                }
            };
            
            ws.onclose = () => {
                console.log('WebSocket disconnected');
                document.getElementById('wsStatus').className = 'ws-disconnected';
                document.getElementById('wsStatus').textContent = '● Disconnected';
                document.getElementById('modeStatus').className = 'status-badge status-disconnected';
                document.getElementById('modeStatus').textContent = 'DISCONNECTED';
                
                if (!reconnectInterval) {
                    reconnectInterval = setInterval(connect, 3000);
                }
            };
            
            ws.onerror = (err) => {
                console.error('WebSocket error:', err);
            };
            
            ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    updateDashboard(data);
                } catch (e) {
                    console.error('Parse error:', e);
                }
            };
        }
        
        function updateDashboard(data) {
            // Mode
            const modeEl = document.getElementById('modeStatus');
            if (data.shadow_mode) {
                modeEl.className = 'status-badge status-shadow';
                modeEl.textContent = 'SHADOW';
            } else {
                modeEl.className = 'status-badge status-live';
                modeEl.textContent = 'LIVE';
            }
            
            // Uptime
            if (data.uptime_ms) {
                const secs = Math.floor(data.uptime_ms / 1000);
                const h = Math.floor(secs / 3600);
                const m = Math.floor((secs % 3600) / 60);
                const s = secs % 60;
                document.getElementById('uptime').textContent = 
                    `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
            }
            
            // FIX status
            document.getElementById('fixQuote').textContent = data.fix_quote ? '✓ Connected' : '✗ Disconnected';
            document.getElementById('fixQuote').className = 'metric-value ' + (data.fix_quote ? 'positive' : 'negative');
            document.getElementById('fixTrade').textContent = data.fix_trade ? '✓ Connected' : '✗ Disconnected';
            document.getElementById('fixTrade').className = 'metric-value ' + (data.fix_trade ? 'positive' : 'negative');
            
            // Session
            if (data.session) {
                document.getElementById('session').textContent = data.session;
            }
            
            // Totals
            document.getElementById('totalTrades').textContent = data.total_trades || 0;
            const totalPnl = data.total_pnl || 0;
            document.getElementById('totalPnl').textContent = '$' + totalPnl.toFixed(2);
            document.getElementById('totalPnl').className = 'metric-value ' + (totalPnl > 0 ? 'positive' : totalPnl < 0 ? 'negative' : 'neutral');
            
            // Gold
            if (data.gold) {
                document.getElementById('goldPrice').textContent = `${data.gold.bid?.toFixed(2) || '--'} / ${data.gold.ask?.toFixed(2) || '--'}`;
                document.getElementById('goldSpread').textContent = (data.gold.spread_bps?.toFixed(2) || '--') + ' bps';
                document.getElementById('goldAtr').textContent = data.gold.atr_ratio?.toFixed(2) || '--';
                document.getElementById('goldRegime').textContent = data.gold.regime || '--';
                document.getElementById('goldPosition').textContent = data.gold.position || 'FLAT';
                const goldPnl = data.gold.pnl || 0;
                document.getElementById('goldPnl').textContent = '$' + goldPnl.toFixed(2);
                document.getElementById('goldPnl').className = 'metric-value ' + (goldPnl > 0 ? 'positive' : goldPnl < 0 ? 'negative' : 'neutral');
            }
            
            // NAS
            if (data.nas) {
                document.getElementById('nasPrice').textContent = `${data.nas.bid?.toFixed(2) || '--'} / ${data.nas.ask?.toFixed(2) || '--'}`;
                document.getElementById('nasSpread').textContent = (data.nas.spread_bps?.toFixed(2) || '--') + ' bps';
                document.getElementById('nasAtr').textContent = data.nas.atr_ratio?.toFixed(2) || '--';
                document.getElementById('nasRegime').textContent = data.nas.regime || '--';
                document.getElementById('nasPosition').textContent = data.nas.position || 'FLAT';
                const nasPnl = data.nas.pnl || 0;
                document.getElementById('nasPnl').textContent = '$' + nasPnl.toFixed(2);
                document.getElementById('nasPnl').className = 'metric-value ' + (nasPnl > 0 ? 'positive' : nasPnl < 0 ? 'negative' : 'neutral');
            }
            
            // Trades
            if (data.trades && data.trades.length > 0) {
                const tradesHtml = data.trades.slice(0, 5).map(t => `
                    <div class="trade-row">
                        <span>${t.instrument} ${t.side}</span>
                        <span class="${t.pnl >= 0 ? 'positive' : 'negative'}">${t.r_multiple?.toFixed(2) || '--'}R ($${t.pnl?.toFixed(2) || '--'})</span>
                    </div>
                `).join('');
                document.getElementById('trades').innerHTML = tradesHtml;
            }
            
            // Timestamp
            document.getElementById('lastUpdate').textContent = 'Last update: ' + new Date().toLocaleTimeString();
        }
        
        connect();
    </script>
</body>
</html>)HTML";
    }
    
    std::string generate_accept_key(const std::string& client_key) noexcept {
        std::string magic = client_key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
        
        unsigned char hash[SHA_DIGEST_LENGTH];
        SHA1((const unsigned char*)magic.c_str(), magic.length(), hash);
        
        return base64_encode(hash, SHA_DIGEST_LENGTH);
    }
    
    std::vector<uint8_t> make_ws_frame(const std::string& data) noexcept {
        std::vector<uint8_t> frame;
        size_t len = data.length();
        
        frame.push_back(0x81);  // FIN + text frame
        
        if (len <= 125) {
            frame.push_back((uint8_t)len);
        } else if (len <= 65535) {
            frame.push_back(126);
            frame.push_back((len >> 8) & 0xFF);
            frame.push_back(len & 0xFF);
        } else {
            frame.push_back(127);
            for (int i = 7; i >= 0; --i) {
                frame.push_back((len >> (i * 8)) & 0xFF);
            }
        }
        
        frame.insert(frame.end(), data.begin(), data.end());
        return frame;
    }
    
    uint16_t port_;
    std::atomic<bool> running_;
    SOCKET server_socket_;
    std::thread accept_thread_;
    
    mutable std::mutex clients_mutex_;
    std::vector<SOCKET> clients_;
};

// ═══════════════════════════════════════════════════════════════════════════════
// GLOBAL INSTANCE
// ═══════════════════════════════════════════════════════════════════════════════

inline DashboardServer& getDashboardServer() noexcept {
    static DashboardServer instance(8080);
    return instance;
}

}  // namespace Alpha
