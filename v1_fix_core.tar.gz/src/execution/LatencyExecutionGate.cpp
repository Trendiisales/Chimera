#include "execution/LatencyExecutionGate.hpp"

// Header-only implementation - nothing required here.
// This file exists only to keep build systems happy.
